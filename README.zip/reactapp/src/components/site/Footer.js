import '../../App.css'
import { useEffect, useState } from 'react';

export default function Footer({children}) {
    return (
        <>
             <h2>Footer</h2>
        </>
    );
  }